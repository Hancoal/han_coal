-- DropIndex
DROP INDEX `Sitter_sitter_name_key` ON `sitter`;

-- DropIndex
DROP INDEX `Sitter_sitter_nickname_key` ON `sitter`;

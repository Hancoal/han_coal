-- DropForeignKey
ALTER TABLE `sitter` DROP FOREIGN KEY `Sitter_sitter_name_fkey`;

-- DropForeignKey
ALTER TABLE `sitter` DROP FOREIGN KEY `Sitter_sitter_nickname_fkey`;

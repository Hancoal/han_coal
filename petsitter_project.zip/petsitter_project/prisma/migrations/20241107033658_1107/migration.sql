/*
  Warnings:

  - A unique constraint covering the columns `[sitter_name]` on the table `Sitter` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[sitter_nickname]` on the table `Sitter` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[name]` on the table `User` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE `sitter` ADD COLUMN `sitter_name` VARCHAR(191) NULL,
    ADD COLUMN `sitter_nickname` VARCHAR(191) NULL;

-- CreateIndex
CREATE UNIQUE INDEX `Sitter_sitter_name_key` ON `Sitter`(`sitter_name`);

-- CreateIndex
CREATE UNIQUE INDEX `Sitter_sitter_nickname_key` ON `Sitter`(`sitter_nickname`);

-- CreateIndex
CREATE UNIQUE INDEX `User_name_key` ON `User`(`name`);

-- AddForeignKey
ALTER TABLE `Sitter` ADD CONSTRAINT `Sitter_sitter_name_fkey` FOREIGN KEY (`sitter_name`) REFERENCES `User`(`name`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Sitter` ADD CONSTRAINT `Sitter_sitter_nickname_fkey` FOREIGN KEY (`sitter_nickname`) REFERENCES `User`(`nickname`) ON DELETE SET NULL ON UPDATE CASCADE;

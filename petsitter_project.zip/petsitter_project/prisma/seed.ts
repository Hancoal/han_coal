import { PrismaClient, Gender } from '@prisma/client'; // Gender 타입을 import
const prisma = new PrismaClient();

async function main() {
  // 500명의 더미 사용자 데이터를 생성
  const users = Array.from({ length: 500 }, (_, index) => ({
    id: `dummy_user_${index + 1}`,          // userId
    name: `Dummy User ${index + 1}`,
    nickname: `DummyNickname${index + 1}`,
    password: 'password123',                 // 공통 비밀번호
    phone: `010-0000-00${String(index + 1).padStart(3, '0')}`, // 전화번호
    gender: index % 2 === 0 ? Gender.MALE : Gender.FEMALE, // Prisma의 Gender enum을 사용
    email: `dummy${index + 1}@example.com`,
    address: 'Some address',
    detailedAddress: 'Some detailed address',
    birthdate: '1990-01-01',
    role: 'SITTER',                          // 역할을 SITTER로 설정
  }));

  // User 테이블에 500명의 더미 사용자 생성
  await prisma.user.createMany({ data: users });
  console.log('500 Dummy Users created!');

  // 500명의 더미 펫시터 데이터를 생성
  const sitters = Array.from({ length: 500 }, (_, index) => ({
    certification: `Certification ${index + 1}`,
    experience: Math.floor(Math.random() * 10) + 1, // 1~10 사이의 경험치
    bio: `Hello, I am Pet Sitter ${index + 1}`,     // 자기소개

    size_exp: Math.floor(Math.random() * 3) + 1,    // 1~3 사이의 크기 전문성
    age_exp: Math.floor(Math.random() * 5) + 1,     // 1~5 사이의 나이 전문성
    bmi_exp: Math.floor(Math.random() * 5) + 1,     // 1~5 사이의 비만도 전문성
    surgical_exp: Math.floor(Math.random() * 5) + 1,// 1~5 사이의 외과적 질환 전문성
    internal_exp: Math.floor(Math.random() * 5) + 1,// 1~5 사이의 내과적 질환 전문성
    activity_exp: Math.floor(Math.random() * 5) + 1,// 1~5 사이의 활동성 전문성
    sociability_exp: Math.floor(Math.random() * 5) + 1, // 1~5 사이의 사교성 전문성
    affinity_exp: Math.floor(Math.random() * 5) + 1,    // 1~5 사이의 친화력 전문성
    aggressive_exp: Math.floor(Math.random() * 5) + 1,  // 1~5 사이의 공격성 전문성

    userId: `dummy_user_${index + 1}`,           // User와 연결할 userId
  }));

  // Sitter 테이블에 500명의 더미 펫시터 생성
  await prisma.sitter.createMany({ data: sitters });
  console.log('500 Pet Sitters created!');
}

main()
  .catch((e) => console.error(e))
  .finally(async () => {
    await prisma.$disconnect();
  });

// src/app.module.ts

import { Module } from "@nestjs/common";
import { AuthController } from "./auth/auth.controller";
import { AppController } from "./app.controller";
import { AppService } from "./app.service";
import { UsersModule } from "./users/users.module";
import { SittersModule } from "./sitters/sitters.module";
import { AuthModule } from "./auth/auth.module";
import { ConfigModule } from "@nestjs/config";
import { BoardModule } from "board/board.module";
import { ReplyModule } from "reply/reply.module";
import { PetsModule } from "pets/pets.module";
import { ChatModule } from "chat/chat.module";
import { RecommendationModule } from "./recommendation/recommendation.module";

@Module({
  imports: [
    PetsModule,
    UsersModule,
    SittersModule,
    AuthModule,
    ReplyModule,
    BoardModule,
    ChatModule,
    RecommendationModule,
    ConfigModule.forRoot({
      isGlobal: true,
    }),
  ],
  controllers: [AuthController, AppController],
  providers: [AppService],
})
export class AppModule {}

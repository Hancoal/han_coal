// src/chat/chat.service.ts

import { Injectable, BadRequestException } from "@nestjs/common";
import { PrismaService } from "prisma/prisma.service";

@Injectable()
export class ChatService {
  constructor(private prisma: PrismaService) {}

  async createChatRoom(userId1: string, userId2: string) {
    if (userId1 === userId2) {
      throw new BadRequestException(
        "같은 사용자 간의 채팅방은 생성할 수 없습니다."
      );
    }
    const existingChatRoom = await this.prisma.chatRoom.findFirst({
      where: {
        OR: [
          { userId1, userId2 },
          { userId1: userId2, userId2: userId1 },
        ],
      },
    });

    if (existingChatRoom) {
      return existingChatRoom;
    }

    return await this.prisma.chatRoom.create({
      data: { userId1, userId2 },
    });
  }

  async sendMessage(chatRoomId: number, senderId: string, content: string) {
    const chatRoom = await this.prisma.chatRoom.findUnique({
      where: { id: chatRoomId },
    });

    if (!chatRoom) {
      throw new BadRequestException("채팅방이 존재하지 않습니다.");
    }

    return await this.prisma.message.create({
      data: { chatRoomId, senderId, content },
    });
  }

  async getMessages(chatRoomId: number) {
    return this.prisma.message.findMany({
      where: { chatRoomId },
      orderBy: { createdAt: "asc" },
    });
  }

  async getUserChatRooms(userId: string) {
    return this.prisma.chatRoom.findMany({
      where: {
        OR: [
          { userId1: userId },
          { userId2: userId }
        ]
      },
      select: {
        id: true,
        userId1: true,
        userId2: true,
        createdAt: true,
}
    });
  }

      async createChatRoomTest(userId1: string, userId2: string) {
    const existingChatRoom = await this.prisma.chatRoom.findFirst({
      where: {
        OR: [
          { userId1, userId2 },
          { userId1: userId2, userId2: userId1 },
        ],
      },
    });

    if (existingChatRoom) {
      return existingChatRoom;
    }

    return await this.prisma.chatRoom.create({
      data: { userId1, userId2 },
    });
  }
}

// src/chat/chat.gateway.ts

import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
  OnGatewayConnection,
  OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { ChatService } from './chat.service';
import { JwtService } from '@nestjs/jwt';
import { UnauthorizedException } from '@nestjs/common';

@WebSocketGateway({
  namespace: '/chat', 
  cors: { origin: '*' },
})
export class ChatGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  constructor(
    private readonly chatService: ChatService,
    private readonly jwtService: JwtService, // JWT 서비스 주입
  ) {}

  // WebSocket 연결 시 JWT 인증
  async handleConnection(client: Socket) {
    const token = client.handshake.auth.token;
    try {
      const payload = this.jwtService.verify(token); // 토큰 검증
      client.data.user = payload; // 검증된 사용자 정보 저장
    } catch (error) {
      client.disconnect(); // 인증 실패 시 연결 해제
      throw new UnauthorizedException();
    }
  }

  handleDisconnect(client: Socket) {
    console.log(`Client disconnected: ${client.id}`);
  }

  @SubscribeMessage('joinRoom')
  async handleJoinRoom(
    @MessageBody('chatRoomId') chatRoomId: number,
    @ConnectedSocket() client: Socket,
  ) {
    client.join(`room-${chatRoomId}`);
  }

  @SubscribeMessage('sendMessage')
  async handleMessage(
    @MessageBody('chatRoomId') chatRoomId: number,
    @MessageBody('content') content: string,
    @ConnectedSocket() client: Socket,
  ) {
    const senderId = client.data.user.id; // 연결된 사용자 ID
    const message = await this.chatService.sendMessage(
      chatRoomId,
      senderId,
      content,
    );

    this.server.to(`room-${chatRoomId}`).emit('receiveMessage', message);
  }
}

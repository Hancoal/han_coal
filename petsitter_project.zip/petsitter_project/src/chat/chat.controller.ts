// src/chat/chat.controller.ts

import {
  Controller,
  Post,
  Body,
  Param,
  Get,
  Req,
  UseGuards,
} from "@nestjs/common";
import { ChatService } from "./chat.service";
import { JwtAuthGuard } from "../../common/guard/jwt-auth.guard";
import { ApiTags, ApiBearerAuth } from "@nestjs/swagger";
import { userIdArgs } from "./dto/userId.args";
import { testArgs } from "./dto/test.args";


@ApiTags("Chat")
@Controller("chat")
export class ChatController {
  constructor(private chatService: ChatService) {}

  @Post("rooms")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  async createChatRoom(@Body() { userId }: { userId: string }, @Req() req) {
    const requesterId = req.user.id;
    return await this.chatService.createChatRoom(requesterId, userId);
  }

  @Post("rooms/:chatRoomId/messages")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  async sendMessage(
    @Param("chatRoomId") chatRoomId: number,
    @Body() { content }: { content: string },
    @Req() req
  ) {
    const senderId = req.user.id;
    return await this.chatService.sendMessage(Number(chatRoomId), senderId, content);
  }

  @Get("rooms/:chatRoomId/messages")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  async getMessages(@Param("chatRoomId") chatRoomId: number) {
    return this.chatService.getMessages(Number(chatRoomId));
  }

    @Post("search/rooms") //userId번호로 글 정보 검색, 가져오기
  async getUserChatRooms(@Body() body: userIdArgs) {
    const chatRoom = await this.chatService.getUserChatRooms(body.userId);
    if (!chatRoom) {
      return { message: "해당 ID의 게시물을 찾을 수 없습니다." };
    }
    return chatRoom;
  }

  @Post("test/rooms") //테스트용 채팅방 만들기
  async createChatRoomTest(@Body() body: testArgs) {
    return await this.chatService.createChatRoomTest(body.userId111, body.userId222);
  }
}

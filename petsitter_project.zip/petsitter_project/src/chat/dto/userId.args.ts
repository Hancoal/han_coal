// src/board/dto/delete.args.ts

import { ApiProperty } from "@nestjs/swagger";
import { IsInt, IsString, IsNotEmpty } from "class-validator";

export class userIdArgs {
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  userId: string;
}

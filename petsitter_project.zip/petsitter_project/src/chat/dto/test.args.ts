import { ApiProperty } from "@nestjs/swagger";
import { IsInt, IsString, IsNotEmpty } from "class-validator";

export class testArgs {
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  userId111: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  userId222: string;
}
// src/board/board.service.ts

import { Injectable } from "@nestjs/common";
import { PrismaService } from "prisma/prisma.service";
import { Board, Tag } from "@prisma/client";

@Injectable()
export class BoardService {
  constructor(private prisma: PrismaService) {}

  async create(
    title: string,
    content: string,
    userId: string,
    tag: Tag
  ): Promise<boolean> {
    try {
      const board = await this.prisma.board.create({
        data: {
          title,
          content,
          date: new Date(),
          userId,
          like: 0,
          tag: tag,
        },
      });
      return true;
    } catch (error) {
      console.error("Error creating board entry:", error);
      return false;
    }
  }

  async getBoardList() {
    return this.prisma.board.findMany({
      select: {
        id: true,
        title: true,
        date: true,
        like: true,
        tag: true,
      },
    });
  }

  async getBoardListTag(tag: Tag) {
    return this.prisma.board.findMany({
      where: { tag },
      select: {
        id: true,
        title: true,
        date: true,
        like: true,
        tag: true,
      },
    });
  }

  async getBoardById(id: number) {
    return this.prisma.board.findUnique({
      where: {
        id: id,
      },
      select: {
        id: true,
        title: true,
        content: true,
        date: true,
        like: true,
        tag: true,
      },
    });
  }

      async getBoardByuserId(userId: string) {
    return this.prisma.board.findMany({
      where: {
        userId: userId
      },
      select: {
        id: true,
        title: true,
        content: true,
        date: true,
        like: true,
        tag: true,
      },
    });
  }

  async like(id: number): Promise<boolean> {
    try {
      await this.prisma.board.update({
        where: { id: id },
        data: {
          like: {
            increment: 1,
          },
        },
      });
      return true;
    } catch (error) {
      console.error("Error updating like:", error);
      return false;
    }
  }

  async deleteBoard(id: number, userId: string): Promise<boolean> {
    try {
      const board = await this.prisma.board.findUnique({
        where: { id: id },
      });

      if (!board) {
        throw new Error("해당 ID의 게시물이 존재하지 않습니다.");
      } else {
        await this.prisma.board.delete({
          where: { id: id, userId: userId },
        });
        return true;
      }
    } catch (error) {
      console.error(error);
      return false;
    }
  }
}

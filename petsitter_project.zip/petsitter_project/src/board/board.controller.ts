// src/board/board.controller.ts

import {
  Controller,
  Post,
  Body,
  Get,
  Param,
  Patch,
  Delete,
  Req,
  Res,
  Query,
  HttpStatus,
  UseGuards,
} from "@nestjs/common";
import { BoardService } from "./board.service";
import { ApiTags, ApiOperation, ApiBearerAuth } from "@nestjs/swagger";
import { CreateBoardArgs } from "./dto/create-board.args";
import { ListTagArgs } from "./dto/listTag.args";
import { RecommendArgs } from "./dto/recommend.args";
import { DeleteArgs } from "./dto/delete.args";
import { userIdArgs } from "./dto/userId.args";
import { JwtAuthGuard } from "../../common/guard/jwt-auth.guard";

@ApiTags("Board")
@Controller("board")
export class BoardController {
  constructor(private boardService: BoardService) {}

  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  @Post("write") //글 쓰기
  async write(
    @Body()
    body: CreateBoardArgs
  ) {
    return this.boardService.create(
      body.title,
      body.content,
      body.userId,
      body.tag
    );
  }

  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  @Post("list") //글 목록보기
  async getBoardList(@Body() body: {}) {
    const boards = await this.boardService.getBoardList();
    return boards;
  }

  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  @Post("list/Tag") //글 목록보기(태그기준)
  async getBoardListTag(@Body() body: ListTagArgs) {
    const boards = await this.boardService.getBoardListTag(body.tag);
    return boards;
  }

  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  @Post("search/id") //id번호로 글 정보 검색, 가져오기
  async getBoardById(@Body("id") id: string) {
    const board = await this.boardService.getBoardById(Number(id));
    if (!board) {
      return { message: "해당 ID의 게시물을 찾을 수 없습니다." };
    }
    return board;
  }

  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  @Post("search/userId") //userId번호로 글 정보 검색, 가져오기
  async getBoardByuserId(@Body() body: userIdArgs) {
    const board = await this.boardService.getBoardByuserId(body.userId);
    if (!board) {
      return { message: "해당 ID의 게시물을 찾을 수 없습니다." };
    }
    return board;
  }

  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  @Patch("like") //글 추천하기
  async incrementlike(
    @Body()
    body: RecommendArgs
  ) {
    const success = await this.boardService.like(body.id);
    if (success) {
      return { message: "추천이 성공적으로 반영되었습니다." };
    } else {
      return { message: "추천 반영에 실패했습니다." };
    }
  }

  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  @Delete("delete") // board의 id와 userId로 글 삭제
  async deleteBoard(@Body() body: DeleteArgs) {
    const success = await this.boardService.deleteBoard(body.id, body.userId);

    if (success) {
      return { message: "성공적으로 삭제되었습니다." };
    } else {
      return { message: "글 삭제에 실패했습니다." };
    }
  }
}

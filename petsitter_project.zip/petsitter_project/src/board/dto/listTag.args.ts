// src/board/dto/listTag.args.ts

import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty } from "class-validator";
import { Tag } from "@prisma/client";

export class ListTagArgs {
  @IsEnum(Tag)
  @IsNotEmpty()
  @ApiProperty()
  tag: Tag;
}

// src/board/dto/recommend.args.ts

import { ApiProperty } from "@nestjs/swagger";
import { IsInt, IsNotEmpty } from "class-validator";

export class RecommendArgs {
  @IsInt()
  @IsNotEmpty()
  @ApiProperty()
  id: number;
}

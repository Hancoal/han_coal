// src/board/dto/create-board.args.ts

import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty, IsString, IsInt } from "class-validator";
import { Tag } from "@prisma/client";
import { ServerDescription } from "typeorm";

export class CreateBoardArgs {
  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    description: "게시글 제목",
    example: "제목을 입력하세요.",
  })
  title: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    description: "게시글 내용",
    example: "내용을 입력하세요.",
  })
  content: string;

  @IsEnum(Tag)
  @IsNotEmpty()
  @ApiProperty({
    description: "게시글 태그",
    example: "태그를 설정하세요.",
  })
  tag: Tag;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    description: "사용자 아이디",
    example: "사용자 아이디",
  })
  userId: string;
}

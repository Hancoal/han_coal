// src/board/dto/delete.args.ts

import { ApiProperty } from "@nestjs/swagger";
import { IsInt, IsString, IsNotEmpty } from "class-validator";

export class DeleteArgs {
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  userId: string;

  @IsInt()
  @IsNotEmpty()
  @ApiProperty()
  id: number;
}

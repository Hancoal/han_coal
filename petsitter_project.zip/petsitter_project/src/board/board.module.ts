// src/board/board.module.ts

import { Module } from "@nestjs/common";
import { BoardService } from "./board.service";
import { BoardController } from "./board.controller";
import { PrismaService } from "prisma/prisma.service";
import { ConfigModule, ConfigService } from "@nestjs/config";

@Module({
  imports: [],
  providers: [BoardService, PrismaService],
  controllers: [BoardController],
  exports: [BoardService],
})
export class BoardModule {}

// src/auth/dto/login.dto.ts

import { IsString, IsNotEmpty } from "class-validator";
import { ApiProperty } from "@nestjs/swagger";

export class LoginDto {
  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    description: "사용자 아이디",
    example: "아이디를 입력하세요.",
  })
  id: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    description: "비밀번호",
    example: "비밀번호를 입력하세요.",
  })
  password: string;
}

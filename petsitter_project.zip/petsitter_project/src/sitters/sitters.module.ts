// src/sitters/sitters.module.ts

import { Module } from "@nestjs/common";
import { SittersService } from "./sitters.service";
import { SittersController } from "./sitters.controller";
import { PrismaService } from "prisma/prisma.service";

@Module({
  providers: [SittersService, PrismaService],
  controllers: [SittersController],
  exports: [SittersService],
})
export class SittersModule {}

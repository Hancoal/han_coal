// src/sitters/sitters.controller.ts

import {Controller,Post,Body,Res,HttpStatus,UseGuards,Req,Patch,BadRequestException,} from "@nestjs/common";
import { AuthService } from "../auth/auth.service";
import { Response } from "express";
import { SittersService } from "./sitters.service";
import { ApiBearerAuth, ApiBody, ApiResponse, ApiTags } from "@nestjs/swagger";
import { CreateSitterArgs } from "./dto/create-sitter.args";
import { JwtAuthGuard } from "../../common/guard/jwt-auth.guard";
import { UpdateSitterArgs } from "./dto/update-sitter.args";
import { PrismaClient } from '@prisma/client';



@ApiTags("Sitters")
@Controller("sitters")
export class SittersController {
  constructor(private sitterService: SittersService) {}
  

  @Post("register")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  async register(
    // 시터 등록
    @Req() req,
    @Body() CreateSitterArgs: CreateSitterArgs,
    @Res() res: Response
  ) {
    try {
      const userId = req.user.id;

      const existingSitter = await this.sitterService.findByUserId(userId);
      if (existingSitter) {
        return res
          .status(HttpStatus.BAD_REQUEST)
          .json({ message: "이미 시터로 등록되어있습니다." });
      }

      await this.sitterService.addSitterRole(
        userId,
        CreateSitterArgs.certification,
        CreateSitterArgs.experience,
        CreateSitterArgs.bio,
        CreateSitterArgs.size_exp,
        CreateSitterArgs.age_exp,
        CreateSitterArgs.bmi_exp,
        CreateSitterArgs.surgical_exp,
        CreateSitterArgs.internal_exp,
        CreateSitterArgs.activity_exp,
        CreateSitterArgs.sociability_exp,
        CreateSitterArgs.affinity_exp,
        CreateSitterArgs.aggressive_exp
      );
      await this.sitterService.updateSitterNames();
      return res
        .status(HttpStatus.CREATED)
        .json({ message: "시터로 등록 되었습니다." });
    } catch (error) {
      return res
        .status(HttpStatus.BAD_REQUEST)
        .json({ message: "시터 등록에 실패했습니다." });
    }
  }

  @Patch("update")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  async updateSitterInfo(
    @Req() req,
    @Body() updateSitterArgs: UpdateSitterArgs,
    @Res() res: Response
  ) {
    try {
      const userId = req.user.id;
      const result = await this.sitterService.updateSitterInfo(
        userId,
        updateSitterArgs
      );
      return res.status(200).json(result);
    } catch (error: any) {
      const errorMessage =
        error instanceof BadRequestException
          ? error.message
          : "시터 정보 수정 중 오류가 발생했습니다.";
      return res.status(400).json({ message: error.message, success: false });
    }
  }
}

// src/sitters/sitters.service.ts

import { BadRequestException, Injectable } from "@nestjs/common";
import { PrismaService } from "prisma/prisma.service";
import { UpdateSitterArgs } from "./dto/update-sitter.args";
import { PrismaClient } from '@prisma/client';


@Injectable()
export class SittersService {
  constructor(private prisma: PrismaService) {}

  async findByUserId(userId: string) {
    return this.prisma.sitter.findUnique({
      where: { userId },
    });
  }

  async updateSitterInfo(userId: string, UpdateSitterArgs: UpdateSitterArgs) {
    // User와 Sitter 데이터 가져오기
    const user = await this.prisma.user.findUnique({
        where: { id: userId },
        select: { name: true, nickname: true },
    });

    if (!user) {
        throw new BadRequestException("사용자를 찾을 수 없습니다.");
    }

    const existingSitter = await this.prisma.sitter.findUnique({
        where: { userId },
    });

    if (!existingSitter) {
        throw new BadRequestException("시터로 등록되지 않은 사용자입니다.");
    }

    const {
        certification,
        experience,
        bio,
        size_exp,
        age_exp,
        bmi_exp,
        surgical_exp,
        internal_exp,
        activity_exp,
        sociability_exp,
        affinity_exp,
        aggressive_exp,
    } = UpdateSitterArgs;

    // 시터 정보 업데이트
    try {
       await this.prisma.sitter.update({
    where: { userId },
    data: {
        sitter_name: user.name, // User 테이블의 name 값을 저장
        sitter_nickname: user.nickname, // User 테이블의 nickname 값을 저장
        certification: certification || existingSitter.certification,
        experience: experience !== undefined ? experience : existingSitter.experience,
        bio: bio || existingSitter.bio,
        size_exp: size_exp || existingSitter.size_exp,
        age_exp: age_exp || existingSitter.age_exp,
        bmi_exp: bmi_exp || existingSitter.bmi_exp,
        surgical_exp: surgical_exp || existingSitter.surgical_exp,
        internal_exp: internal_exp || existingSitter.internal_exp,
        activity_exp: activity_exp || existingSitter.activity_exp,
        sociability_exp: sociability_exp || existingSitter.sociability_exp,
        affinity_exp: affinity_exp || existingSitter.affinity_exp,
        aggressive_exp: aggressive_exp || existingSitter.aggressive_exp,
    },
});

        console.log("Sitter information updated successfully."); // 업데이트 성공 메시지 출력
        return { message: "시터 정보가 성공적으로 수정되었습니다." };
    } catch (error) {
        console.error("Error updating sitter information:", error); // 에러 메시지 출력
        throw new BadRequestException("시터 정보 수정 중 오류가 발생했습니다.");
    }
  }

  // addSitterRole 메서드
  async addSitterRole(
    userId: string,
    certification: string | null,
    experience: number | null,
    bio: string | null,
    size_exp: number,
    age_exp: number,
    bmi_exp: number,
    surgical_exp: number,
    internal_exp: number,
    activity_exp: number,
    sociability_exp: number,
    affinity_exp: number,
    aggressive_exp: number
  ): Promise<boolean> {
    // 사용자가 이미 시터로 등록되어 있는지 확인
    const existingSitter = await this.findByUserId(userId);
    if (existingSitter) {
      throw new BadRequestException("이미 시터로 등록되어있습니다");
    }
    // 사용자 정보를 가져와 현재 역할 확인
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
    });

    // 기존 역할에 'SITTER'가 없는 경우 추가
    let updatedRole = user.role;
    if (!user.role.includes("SITTER")) {
      updatedRole = `${user.role},SITTER`;
    }

    // 역할 업데이트
    await this.prisma.user.update({
      where: { id: userId },
      data: {
        role: updatedRole, // 쉼표로 구분된 문자열로 저장
      },
    });

    // Sitter 테이블에 정보 추가
    await this.prisma.sitter.create({
      data: {
        userId,
        certification,
        experience,
        bio,
        size_exp,
        age_exp,
        bmi_exp,
        surgical_exp,
        internal_exp,
        activity_exp,
        sociability_exp,
        affinity_exp,
        aggressive_exp,
      },
    });

    return true;
  }

    async updateSitterNames() {
    // Sitter 테이블의 sitter_name과 sitter_nickname 필드를 User 테이블의 name과 nickname 필드로 업데이트
    await this.prisma.$executeRaw`
      UPDATE sitter s
      JOIN user u ON s.userId = u.id
      SET s.sitter_name = u.name,
          s.sitter_nickname = u.nickname;
    `;
  }
}

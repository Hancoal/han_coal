// src/sitters/dto/update-sitter.args.ts

import { ApiProperty } from "@nestjs/swagger";
import {
  IsOptional,
  IsString,
  IsInt,
  IsNumber,
  Min,
  Max,
} from "class-validator";

export class UpdateSitterArgs {
  @IsOptional()
  @IsString()
  @ApiProperty({
    description: "자신의 전문성",
    example: "자격증, 자신의 전문분야 등",
  })
  certification: string | null;

  @IsOptional()
  @IsInt()
  @ApiProperty({
    description: "시터 경험",
    example: 3,
  })
  experience: number | null;

  @IsOptional()
  @IsString()
  @ApiProperty({
    description: "자기소개 및 시터 설명",
    example: "저는 ~~전문 시터이며 ~~서비스를 제공합니다.",
  })
  bio: string | null;

  @IsNumber()
  @Min(1)
  @Max(3)
  @ApiProperty({
    description: "크기 전문성",
    example: 2,
  })
  size_exp: number;

  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "나이 전문성",
    example: 3,
  })
  age_exp: number;

  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "비만도 전문성",
    example: 2,
  })
  bmi_exp: number;

  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "외과적 질환 전문성",
    example: 1,
  })
  surgical_exp: number;

  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "내과적 질환 전문성",
    example: 2,
  })
  internal_exp: number;

  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "활동성 전문성",
    example: 4,
  })
  activity_exp: number;

  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "사교성 전문성",
    example: 3,
  })
  sociability_exp: number;

  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "친화력 전문성",
    example: 4,
  })
  affinity_exp: number;

  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "공격성 전문성",
    example: 1,
  })
  aggressive_exp: number;
}

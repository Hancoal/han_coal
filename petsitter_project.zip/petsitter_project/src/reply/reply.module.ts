// src/reply/reply.module.ts

import { Module } from "@nestjs/common";
import { ReplyService } from "./reply.service";
import { ReplyController } from "./reply.controller";
import { PrismaService } from "prisma/prisma.service";

@Module({
  controllers: [ReplyController],
  providers: [ReplyService, PrismaService],
})
export class ReplyModule {}

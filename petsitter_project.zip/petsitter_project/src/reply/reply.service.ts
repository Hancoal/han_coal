// src/reply/reply.service.ts

import { Injectable } from "@nestjs/common";
import { PrismaService } from "prisma/prisma.service";
import { Reply } from "@prisma/client";

@Injectable()
export class ReplyService {
  constructor(private prisma: PrismaService) {}

  async createReply(
    boardId: number,
    userId: string,
    content: string
  ): Promise<Reply> {
    return this.prisma.reply.create({
      data: {
        boardId,
        userId,
        content,
      },
    });
  }

  async getReplyByBoardId(boardId: number) {
    return this.prisma.reply.findMany({
      where: {
        boardId: boardId,
      },
      select: {
        id: true,
        content: true,
        date: true,
        userId: true,
        boardId: true,
      },
    });
  }

  async deleteReply(id: number, userId: string): Promise<boolean> {
    try {
      const reply = await this.prisma.board.findFirst({
        where: { id: id },
      });

      if (!reply) {
        throw new Error("해당 ID의 댓글이 존재하지 않습니다.");
      } else {
        await this.prisma.reply.delete({
          where: { id: id, userId: userId },
        });
        return true;
      }
    } catch (error) {
      console.error(error);
      return false;
    }
  }
}

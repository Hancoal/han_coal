// src/reply/dto/create-reply.args.ts

import { ApiProperty } from "@nestjs/swagger";
import { IsInt, IsNotEmpty, IsString } from "class-validator";

export class CreateReplyArgs {
  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    description: "댓글 내용",
    example: "내용을 입력하세요.",
  })
  content: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    description: "사용자 아이디",
    example: "사용자 아이디",
  })
  userId: string;

  @IsInt()
  @IsNotEmpty()
  @ApiProperty()
  boardId: number;
}

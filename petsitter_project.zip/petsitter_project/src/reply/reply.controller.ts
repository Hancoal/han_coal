// src/reply/reply.controller.ts

import {
  Controller,
  Post,
  Body,
  Param,
  Get,
  Delete,
  Res,
  Query,
  UseGuards,
} from "@nestjs/common";
import { ReplyService } from "./reply.service";
import { Response } from "express";
import { CreateReplyArgs } from "./dto/create-reply.args";
import { DeleteReplyArgs } from "./dto/delete-reply.args";
import { ApiBearerAuth, ApiTags } from "@nestjs/swagger";
import { JwtAuthGuard } from "../../common/guard/jwt-auth.guard";

@ApiTags("Reply")
@Controller("reply")
export class ReplyController {
  constructor(private readonly replyService: ReplyService) {}

  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  @Post("create") //댓글 생성하기
  async createReply(@Body() body: CreateReplyArgs) {
    return this.replyService.createReply(
      body.boardId,
      body.userId,
      body.content
    );
  }

  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
@Post("search/boardId")
async getReplyByBoardId(@Body("boardId") boardId: string) {  // boardId를 string으로 받습니다
  const reply = await this.replyService.getReplyByBoardId(Number(boardId));
  if (!reply || reply.length === 0) {
    return { message: "해당 ID의 게시물을 찾을 수 없습니다." };
  }
  return reply;
}

  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  @Delete("delete") //reply의 id와 userid로 댓글 삭제
  async deleteReply(@Body() body: DeleteReplyArgs) {
    const success = await this.replyService.deleteReply(body.id, body.userId);

    if (success) {
      return { message: "댓글이 성공적으로 삭제되었습니다." };
    } else {
      return { message: "댓글 삭제에 실패했습니다." };
    }
  }
}

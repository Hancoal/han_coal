// src/main.ts

import { NestFactory } from "@nestjs/core";
import { AppModule } from "./app.module";
import "reflect-metadata";
import { SwaggerModule, DocumentBuilder } from "@nestjs/swagger";
import { ValidationPipe } from "@nestjs/common";

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.enableCors({
    origin: "*", // 필요한 도메인만 허용할 수도 있습니다.
    methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
    credentials: true,
    allowedHeaders:
      "Authorization, Origin, X-Requested-With, Content-Type, Accept",
  });

  app.useGlobalPipes(new ValidationPipe());

  const options = new DocumentBuilder()
    .setTitle("Pet Sitter API")
    .setDescription("Pet Sitter Service API")
    .setVersion("1.0")
    .addBearerAuth(
      { type: "http", scheme: "bearer", name: "JWT", in: "header" },
      "access-token"
    )
    .addServer("http://localhost:3000/", "Local environment")
    .addServer("https://staging.yourapi.com/", "Staging")
    .addServer("https://production.yourapi.com/", "Production")
    .addTag("API")
    .build();

  const document = SwaggerModule.createDocument(app, options);
  SwaggerModule.setup("api-docs", app, document);
  // http://localhost:3000/api-docs#/ #swagger

  await app.listen(3000);
}
bootstrap();

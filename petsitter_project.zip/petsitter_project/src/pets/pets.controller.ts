// src/pets/pets.controller.ts

import {
  Controller,
  Post,
  Body,
  Patch,
  UseGuards,
  BadRequestException,
  HttpStatus,
  Req,
  UploadedFile,
  UseInterceptors,
} from "@nestjs/common";
import { PetsService } from "./pets.service";
import { ApiBearerAuth, ApiConsumes, ApiTags } from "@nestjs/swagger";
import { JwtAuthGuard } from "../../common/guard/jwt-auth.guard";
import { CreatePetArgs } from "./dto/create-pet.args";
import { UpdatePetArgs } from "./dto/update-pet.args";
import { FileInterceptor } from "@nestjs/platform-express";
import { diskStorage } from "multer";
import path from "path";
import { UpdatePetImageArgs } from "./dto/update-pet-image.args";

interface JwtPayload {
  id: string;
  name: string;
}

@ApiTags("Pets")
@Controller("pets")
export class PetsController {
  constructor(private petsService: PetsService) {}

  @Post("register")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  async register(
    @Body() createPetArgs: CreatePetArgs,
    @Req() req // JwtAuthGuard로 인증된 사용자의 ID를 가져옴
  ) {
    try {
      const userId = req.user.id;

      const existingPets = await this.petsService.findByUserId(userId);
      if (existingPets.length >= 5) {
        throw new BadRequestException("최대 5마리의 펫만 등록할 수 있습니다.");
      }

      await this.petsService.addPetRole(
        userId,
        createPetArgs.name,
        createPetArgs.breed,
        Number(createPetArgs.age),
        createPetArgs.size,
        createPetArgs.bmi,
        createPetArgs.surgical,
        createPetArgs.internal,
        createPetArgs.activity,
        createPetArgs.sociability,
        createPetArgs.affinity,
        createPetArgs.aggressive,
        null
      );

      return {
        statusCode: HttpStatus.CREATED,
        message: "펫이 성공적으로 등록되었습니다.",
      };
    } catch (error: any) {
      throw new BadRequestException(error.message || "펫 등록에 실패했습니다.");
    }
  }

  @Patch("update")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  async updatePetInfo(
    @Body() updatePetArgs: UpdatePetArgs,
    @Req() req // JwtAuthGuard로 인증된 사용자의 ID를 가져옴
  ) {
    try {
      const userId = req.user.id;
      const result = await this.petsService.updatePetInfo(
        userId,
        updatePetArgs
      );

      return {
        statusCode: HttpStatus.OK,
        message: "펫 정보가 성공적으로 수정되었습니다.",
        result,
      };
    } catch (error: any) {
      throw new BadRequestException(
        error.message || "펫 정보 수정 중 오류가 발생했습니다."
      );
    }
  }

  @Patch("update-image")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  @UseInterceptors(
    FileInterceptor("petImage", {
      storage: diskStorage({
        destination: path.join(__dirname, "./uploads/petImages"),
        filename: (req, file, cb) => {
          const user = req.user as JwtPayload;
          const ext = path.extname(file.originalname);
          const filename = `${user.id}_${Date.now()}${ext}`;
          cb(null, filename);
        },
      }),
      fileFilter: (req, file, cb) => {
        const ext = path.extname(file.originalname).toLowerCase();
        const allowedExts = [".png", ".jpg", ".jpeg"];
        if (!allowedExts.includes(ext)) {
          return cb(
            new BadRequestException("이미지 파일만 업로드할 수 있습니다."),
            false
          );
        }
        cb(null, true);
      },
    })
  )
  @ApiConsumes("multipart/form-data")
  async updatePetImage(
    @Req() req,
    @Body() updatePetImageArgs: UpdatePetImageArgs,
    @UploadedFile() petImage: Express.Multer.File
  ) {
    try {
      const userId = req.user.id;
      const petImageUrl = `/uploads/petImages/${petImage.filename}`;

      await this.petsService.updatePetImage(
        userId,
        updatePetImageArgs.name,
        petImageUrl
      );

      return {
        statusCode: HttpStatus.OK,
        message: "펫 이미지가 성공적으로 업데이트되었습니다.",
      };
    } catch (error: any) {
      throw new BadRequestException(
        error.message || "펫 이미지 업데이트에 실패했습니다."
      );
    }
  }
}

// src/pets/pets.service.ts

import { BadRequestException, Injectable } from "@nestjs/common";
import { PrismaService } from "prisma/prisma.service";
import { CreatePetArgs } from "./dto/create-pet.args";
import { UpdatePetArgs } from "./dto/update-pet.args";

@Injectable()
export class PetsService {
  constructor(private prisma: PrismaService) {}

  async findByUserId(userId: string) {
    return this.prisma.pet.findMany({
      where: { userId },
    });
  }

  // 펫 등록 시 여러 속성을 받는 메서드 추가
  async addPetRole(
    userId: string,
    name: string,
    breed: string,
    age: number,
    size: number,
    bmi: number,
    surgical: number,
    internal: number,
    activity: number,
    sociability: number,
    affinity: number,
    aggressive: number,
    petImageUrl: string | null
  ): Promise<boolean> {
    const existingPets = await this.findByUserId(userId);
    if (existingPets.length >= 5) {
      throw new BadRequestException("최대 5마리의 펫만 등록할 수 있습니다.");
    }

    // Prisma를 사용하여 데이터베이스에 새 펫 등록
    await this.prisma.pet.create({
      data: {
        userId,
        name,
        breed,
        age,
        size,
        bmi,
        surgical,
        internal,
        activity,
        sociability,
        affinity,
        aggressive,
        petImageUrl,
      },
    });

    return true;
  }

  async updatePetInfo(userId: string, updatePetArgs: UpdatePetArgs) {
    const existingPet = await this.prisma.pet.findFirst({
      where: { userId, name: updatePetArgs.name },
    });

    if (!existingPet) {
      throw new BadRequestException("등록된 펫을 찾을 수 없습니다.");
    }

    const {
      name,
      breed,
      size,
      age,
      bmi,
      surgical,
      internal,
      activity,
      sociability,
      affinity,
      aggressive,
    } = updatePetArgs;

    try {
      await this.prisma.pet.update({
        where: { userId_name: { userId, name: updatePetArgs.name } },
        data: {
          name: name || existingPet.name,
          breed: breed || existingPet.breed,
          size: size || existingPet.size,
          age: age || existingPet.age,
          bmi: bmi || existingPet.bmi,
          surgical: surgical || existingPet.surgical,
          internal: internal || existingPet.internal,
          activity: activity || existingPet.activity,
          sociability: sociability || existingPet.sociability,
          affinity: affinity || existingPet.affinity,
          aggressive: aggressive || existingPet.aggressive,
        },
      });

      return { message: "펫 정보가 성공적으로 수정되었습니다." };
    } catch (error) {
      throw new BadRequestException("펫 정보 수정 중 오류가 발생했습니다.");
    }
  }

  async updatePetImage(userId: string, name: string, petImageUrl: string) {
    const existingPet = await this.prisma.pet.findFirst({
      where: { name, userId },
    });

    if (!existingPet) {
      throw new BadRequestException("펫을 찾을 수 없습니다.");
    }

    await this.prisma.pet.update({
      where: { userId_name: { userId, name } },
      data: { petImageUrl },
    });
  }
}

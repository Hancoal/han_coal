// src/pets/dto/update-pet.args.ts

import { ApiProperty } from "@nestjs/swagger";
import {
  IsString,
  IsNumber,
  IsOptional,
  Min,
  Max,
  IsInt,
} from "class-validator";

export class UpdatePetArgs {
  @IsString()
  @ApiProperty({
    description: "반려동물 이름",
    example: "콩이",
    required: true,
  })
  name?: string;

  @IsOptional()
  @IsString()
  @ApiProperty({
    description: "반려동물 종",
    example: "푸들",
    required: false,
  })
  breed?: string;

  @IsOptional()
  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "반려동물 크기 (1~5)",
    required: false,
  })
  size?: number;

  @IsOptional()
  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "반려동물 나이 (1~5)",
    required: false,
  })
  age?: number;

  @IsOptional()
  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "비만도 (1~5)",
    required: false,
  })
  bmi?: number;

  @IsOptional()
  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "외과적 질환 (1~5)",
    required: false,
  })
  surgical?: number;

  @IsOptional()
  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "내과적 질환 (1~5)",
    required: false,
  })
  internal?: number;

  @IsOptional()
  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "활동성 (1~5)",
    required: false,
  })
  activity?: number;

  @IsOptional()
  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "사교성 (1~5)",
    required: false,
  })
  sociability?: number;

  @IsOptional()
  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "친화력 (1~5)",
    required: false,
  })
  affinity?: number;

  @IsOptional()
  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "공격성 (1~5)",
    required: false,
  })
  aggressive?: number;
}

// src/pets/dto/create-pet.args.ts

import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsString, IsNumber, Min, Max } from "class-validator";

export class CreatePetArgs {
  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    description: "반려동물의 이름",
    example: "콩이",
  })
  name: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    description: "반려동물의 종류",
    example: "푸들",
  })
  breed: string;

  @IsNumber()
  @Min(1)
  @Max(3)
  @ApiProperty({
    description: "반려동물의 크기",
    example: 2,
  })
  size: number;

  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "반려동물의 나이",
    example: 1,
  })
  age: number;

  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "반려동물의 비만도",
    example: 2,
  })
  bmi: number;

  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "반려동물의 외과적 질환 정도",
    example: 1,
  })
  surgical: number;

  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "반려동물의 내과적 질환 정도",
    example: 2,
  })
  internal: number;

  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "반려동물의 활동성",
    example: 4,
  })
  activity: number;

  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "반려동물의 사교성",
    example: 3,
  })
  sociability: number;

  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "반려동물의 친화력",
    example: 4,
  })
  affinity: number;

  @IsNumber()
  @Min(1)
  @Max(5)
  @ApiProperty({
    description: "반려동물의 공격성",
    example: 1,
  })
  aggressive: number;
}

import { ApiProperty } from "@nestjs/swagger";
import { IsString } from "class-validator";

export class UpdatePetImageArgs {
  @IsString()
  @ApiProperty({
    description: "업데이트할 펫의 이름",
    example: "콩이",
  })
  name: string; // 펫의 이름으로 업데이트를 진행

  @ApiProperty({
    description: "펫 이미지 파일",
    type: "string",
    format: "binary",
  })
  petImage: any; // 파일 업로드 처리를 위한 필드
}

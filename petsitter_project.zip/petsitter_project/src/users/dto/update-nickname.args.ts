// src/users/dto/update-nickname.args.ts

import { ApiProperty } from "@nestjs/swagger";
import { IsString } from "class-validator";

export class UpdateNicknameArgs {
  @IsString()
  @ApiProperty()
  nickname: string;
}

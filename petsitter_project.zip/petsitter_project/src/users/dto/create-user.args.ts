// src/users/dto/create-user.args.ts

import { ApiProperty } from "@nestjs/swagger";
import { Gender } from "@prisma/client";
import { IsEnum, IsNotEmpty, IsString } from "class-validator";

export class CreateUserArgs {
  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    description: "사용자 아이디",
    example: "user123",
  })
  id: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    description: "사용자 이름",
    example: "홍길동",
  })
  name: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    description: "닉네임",
    example: "2~15자 이내",
  })
  nickname: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    description: "비밀번호",
    example: "2~15자 이내",
  })
  password: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    description: "전화번호",
    example: "010-1234-5678",
  })
  phone: string;

  @IsEnum(Gender)
  @IsNotEmpty()
  @ApiProperty({
    description: "성별",
    example: "MALE or FEMALE",
  })
  gender: Gender;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    description: "이메일",
    example: "user@example.com",
  })
  email: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    description: "주소",
    example: "서울특별시 용산구 한남동",
  })
  address: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    description: "상세 주소",
    example: "11-1번지 11아파트 1동 1호",
  })
  detailedAddress: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    description: "생년월일",
    example: "1990-01-01",
  })
  birthdate: string;
}

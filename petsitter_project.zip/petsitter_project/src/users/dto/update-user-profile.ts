// src/users/dto/update-user-profile.ts

import { ApiProperty } from "@nestjs/swagger";
import { IsString, IsOptional } from "class-validator";

export class UpdateUserProfileDto {
  @IsString()
  @IsOptional()
  @ApiProperty()
  nickname?: string;

  @IsString()
  @IsOptional()
  @ApiProperty()
  bio?: string;

  @IsOptional()
  @ApiProperty({ type: "string", format: "binary" })
  profileImage?: any; // 파일 업로드 처리
}

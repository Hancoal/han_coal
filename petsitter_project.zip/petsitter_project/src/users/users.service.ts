// src/users/users.service.ts

import { BadRequestException, Injectable } from "@nestjs/common";
import { PrismaService } from "prisma/prisma.service";
import { Gender, User } from "@prisma/client";
import { AuthService } from "auth/auth.service";
import { ValidateIdArgs } from "./dto/validate-id.args";
import { ValidateNicknameArgs } from "./dto/validate-nickname.args";
import { UpdateUserProfileDto } from "./dto/update-user-profile";
import { SittersService } from "sitters/sitters.service";

@Injectable()
export class UsersService {
  constructor(
    private prisma: PrismaService,
    private authService: AuthService,
    private sittersService: SittersService
  ) {}

  async getUserInfo(id: string) {
    // 유저 정보 조회
    return this.prisma.user.findUnique({ where: { id } });
  }

  async updateProfile(
    // 프로필 업데이트
    userId: string,
    updateUserProfileDto: UpdateUserProfileDto,
    profileImageUrl: string | null
  ): Promise<{ message: string; success: boolean }> {
    const { nickname, bio } = updateUserProfileDto;

    await this.prisma.user.update({
      where: { id: userId },
      data: {
        nickname: nickname || undefined,
        bio: bio || undefined,
        profileImageUrl: profileImageUrl || undefined,
      },
    });

    return {
      message: "프로필이 성공적으로 업데이트되었습니다.",
      success: true,
    };
  }

  // 나이 계산 함수
  calculateAge(birthdate: string): number {
    const birthDate = new Date(birthdate);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();

    if (
      monthDiff < 0 ||
      (monthDiff === 0 && today.getDate() < birthDate.getDate())
    ) {
      age--;
    }

    return age;
  }

  async create(
    // 회원가입
    id: string,
    name: string,
    nickname: string,
    password: string,
    phone: string,
    gender: Gender,
    email: string,
    address: string,
    detailedAddress: string,
    birthdate: string
  ): Promise<{ message: string; success: boolean }> {
    const validateId = await this.validateId({ id });
    const validateNickname = await this.validateNickname({ nickname });
    if (validateId && validateNickname) {
      await this.prisma.user.create({
        data: {
          id,
          address,
          email,
          name,
          nickname,
          password: await this.authService.hashPassword(password),
          phone,
          gender,
          detailedAddress,
          birthdate,
          role: "CUSTOMER",
        },
      });
      return { message: "회원가입에 성공했습니다.", success: true };
    }
    return { message: "회원가입에 실패했습니다.", success: false };
  }

  async registerAsSitter(
    userId: string,
    certification: string | null,
    experience: number | null,
    bio: string | null,
    size_exp: number | null,
    age_exp: number | null,
    bmi_exp: number | null,
    surgical_exp: number | null,
    internal_exp: number | null,
    activity_exp: number | null,
    sociability_exp: number | null,
    affinity_exp: number | null,
    aggressive_exp: number | null
  ): Promise<{ message: string; success: boolean }> {
    await this.sittersService.addSitterRole(
      userId,
      certification,
      experience,
      bio,
      size_exp,
      age_exp,
      bmi_exp,
      surgical_exp,
      internal_exp,
      activity_exp,
      sociability_exp,
      affinity_exp,
      aggressive_exp
    );
    return { message: "시터 역할이 성공적으로 추가되었습니다.", success: true };
  }

  async findOne(id: string): Promise<User | undefined> {
    return this.prisma.user.findFirst({ where: { id } });
  }

  async validateId({
    id,
  }: ValidateIdArgs): Promise<{ message: string; success: boolean }> {
    // 아이디 최소 길이와 최대 길이 설정
    const minLength = 2;
    const maxLength = 15;
    const regex = /^[a-zA-Z0-9]+$/;

    // 아이디 길이 검증
    if (id.length < minLength || id.length > maxLength) {
      throw new BadRequestException({
        message: "아이디의 길이가 맞지 않습니다. 2~15자 사이로 입력해주세요.",
      });
    }

    // 아이디 정규식 검증
    if (!regex.test(id)) {
      throw new BadRequestException({
        message: "아이디에는 영어 대소문자 및 숫자만 사용할 수 있습니다.",
      });
    }

    // 아이디 중복 검증
    const existingUser = await this.findOne(id);
    if (existingUser) {
      throw new BadRequestException({ message: "아이디가 중복되었습니다." });
    }

    return { message: "사용할 수 있는 아이디 입니다.", success: true };
  }

  async validateNickname({
    nickname,
  }: ValidateNicknameArgs): Promise<{ message: string; success: boolean }> {
    // 닉네임 최소 길이와 최대 길이 설정
    const minLength = 2;
    const maxLength = 15;
    const regex = /^[가-힣0-9a-zA-Z]+$/;

    // 닉네임 길이 검증
    if (nickname.length < minLength || nickname.length > maxLength) {
      throw new BadRequestException({
        message: "닉네임의 길이가 맞지 않습니다. 2~15자 사이로 입력해주세요.",
      });
    }

    // 닉네임 정규식 검증
    if (!regex.test(nickname)) {
      throw new BadRequestException({
        message:
          "닉네임에는 영어 대소문자와 한글 및 숫자만 사용할 수 있습니다.",
      });
    }

    // 닉네임 중복 검증
    const existingUser = await this.prisma.user.findFirst({
      where: { nickname },
    });
    if (existingUser) {
      throw new BadRequestException({ message: "닉네임 중복되었습니다." });
    }

    return { message: "사용할 수 있는 닉네임 입니다.", success: true };
  }

  async updateNickname(
    { nickname }: ValidateNicknameArgs,
    userId: string
  ): Promise<{ message: string; success: boolean }> {
    // 닉네임 최소 길이와 최대 길이 설정s
    const minLength = 2;
    const maxLength = 15;
    const regex = /^[가-힣0-9a-zA-Z]+$/;

    // 닉네임 길이 검증
    if (nickname.length < minLength || nickname.length > maxLength) {
      throw new BadRequestException({
        message: "닉네임의 길이가 맞지 않습니다. 2~15자 사이로 입력해주세요.",
      });
    }

    // 닉네임 정규식 검증
    if (!regex.test(nickname)) {
      throw new BadRequestException({
        message:
          "닉네임에는 영어 대소문자와 한글 및 숫자만 사용할 수 있습니다.",
      });
    }

    // 닉네임 중복 검증
    const existingUser = await this.prisma.user.findFirst({
      where: { nickname },
    });
    if (existingUser) {
      throw new BadRequestException({ message: "닉네임 중복되었습니다." });
    }

    this.prisma.user.update({
      where: { id: userId },
      data: { nickname },
    });

    return { message: "닉네임이 변경되었습니다.", success: true };
  }
}

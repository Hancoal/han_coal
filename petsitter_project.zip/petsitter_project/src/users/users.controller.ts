// src/users/users.controller.ts

import {
  Controller,
  Post,
  Body,
  Patch,
  UseGuards,
  Req,
  UploadedFile,
  UseInterceptors,
  BadRequestException,
  Res,
  HttpStatus,
  Get,
} from "@nestjs/common";
import { UsersService } from "./users.service";
import { CreateUserArgs } from "./dto/create-user.args";
import { ValidateIdArgs } from "./dto/validate-id.args";
import { ValidateNicknameArgs } from "./dto/validate-nickname.args";
import { UpdateNicknameArgs } from "./dto/update-nickname.args";
import { JwtAuthGuard } from "../../common/guard/jwt-auth.guard";
import { UpdateUserProfileDto } from "./dto/update-user-profile";
import { FileInterceptor } from "@nestjs/platform-express";
import { diskStorage } from "multer";
import * as path from "path";
import { Request } from "express";
import {
  ApiBearerAuth,
  ApiConsumes,
  ApiResponse,
  ApiTags,
} from "@nestjs/swagger";
import { Response } from "express";

interface JwtPayload {
  id: string;
  name: string;
}
@ApiTags("Users")
@Controller("users")
export class UsersController {
  constructor(private userService: UsersService) {}

  @Get("UserInfo")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  async getUser(@Req() req) {
    const userId = req.user.id;
    return this.userService.getUserInfo(userId);
  }

  @Post("register")
  async register(
    @Body()
    body: CreateUserArgs
  ) {
    await this.userService.create(
      body.id,
      body.name,
      body.nickname,
      body.password,
      body.phone,
      body.gender,
      body.email,
      body.address,
      body.detailedAddress,
      body.birthdate
    );
    return { message: "회원가입에 성공했습니다.", success: true };
  }

  @Post("validate-id")
  async validateId(
    @Body()
    body: ValidateIdArgs
  ) {
    return this.userService.validateId(body);
  }

  @Post("validate-nickname")
  async validateNickname(
    @Body()
    body: ValidateNicknameArgs
  ) {
    return this.userService.validateNickname(body);
  }

  @Patch("nickname")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  async updateNickname(
    @Req() req,
    @Body()
    body: UpdateNicknameArgs
  ) {
    const userId = req.user.id;
    return this.userService.updateNickname(body, userId);
  }
  @Patch("profile")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  @UseInterceptors(
    FileInterceptor("profileImage", {
      storage: diskStorage({
        destination: path.join(__dirname, "./uploads/profileImages"),
        filename: (req, file, cb) => {
          const user = req.user as JwtPayload;
          const ext = path.extname(file.originalname);
          const filename = `${user.id}_${Date.now()}${ext}`;
          cb(null, filename);
        },
      }),
      fileFilter: (req, file, cb) => {
        const ext = path.extname(file.originalname).toLowerCase();
        const allowedExts = [".png", ".jpg", ".jpeg"];
        if (!allowedExts.includes(ext) || !file.mimetype.startsWith("image/")) {
          return cb(
            new BadRequestException("이미지 파일만 업로드할 수 있습니다."),
            false
          );
        }
        cb(null, true);
      },
    })
  )
  @ApiConsumes("multipart/form-data")
  async updateProfile(
    @Req() req,
    @Body() updateUserProfileDto: UpdateUserProfileDto,
    @UploadedFile() profileImage: Express.Multer.File,
    @Res() res: Response // Express Response 타입을 명시적으로 설정
  ) {
    const userId = req.user.id;
    const profileImageUrl = profileImage
      ? `/uploads/profileImages/${profileImage.filename}`
      : null;

    await this.userService.updateProfile(
      userId,
      updateUserProfileDto,
      profileImageUrl
    );
    return res
      .status(200)
      .json({ message: "프로필이 성공적으로 업데이트되었습니다." });
  }
}

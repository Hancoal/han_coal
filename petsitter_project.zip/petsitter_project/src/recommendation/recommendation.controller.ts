// src/recommendation/recommendation.controller.ts

import { Controller, Get, Query, UseGuards } from "@nestjs/common";
import { RecommendationService } from "./recommendation.service";
import { ApiTags, ApiQuery, ApiBearerAuth } from "@nestjs/swagger";
import { JwtAuthGuard } from "../../common/guard/jwt-auth.guard";

@ApiTags("Recommendation")
@Controller("recommendation")
export class RecommendationController {
  constructor(private readonly recommendationService: RecommendationService) {}

  @Get("recommend-sitter")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth("access-token")
  @ApiQuery({ name: "userId", type: String })
  @ApiQuery({
    name: "tab",
    enum: [
      "시간보내기",
      "건강케어",
      "우리집케어",
      "야외활동",
      "산책하기",
      "체중관리",
    ],
  })
  async getRecommendedSitters(
    @Query("userId") userId: number,
    @Query("tab") tab: string
  ) {
    return this.recommendationService.getRecommendedSitters(userId, tab);
  }
}

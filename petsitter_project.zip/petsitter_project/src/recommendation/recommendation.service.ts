// src/recommendation/recommendation.service.ts

import { Injectable, HttpException, HttpStatus } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";

@Injectable()
export class RecommendationService {
  constructor(private prisma: PrismaService) {}

  async getRecommendedSitters(userId: number, tab: string) {
    const userPetInfo = await this.prisma.pet.findFirst({
      where: { userId: userId.toString() },
    });

    if (!userPetInfo) {
      throw new HttpException(
        "No pet information found for this user.",
        HttpStatus.NOT_FOUND
      );
    }

    const sitters = await this.prisma.sitter.findMany();
    const topSitters = this.calculateRecommendation(userPetInfo, sitters, tab);

    return topSitters;
  }

  calculateRecommendation(userInfo, sitters, tab) {
    const weights = this.getWeightsByTab(tab);

    const recommendations = sitters
      .map((sitter) => {
        const jaccardSim = this.jaccardSimilarity(userInfo, sitter);
        console.log(
          `Jaccard Similarity with sitter ${sitter.sitterNum}: ${jaccardSim}`
        );

        if (jaccardSim < 0.5) return null;

        const similarity = this.calculateSimilarity(userInfo, sitter, weights);
        console.log(
          `Weighted Similarity with sitter ${sitter.sitterNum}: ${similarity}%`
        );

        return similarity > 0 ? { sitter, similarity } : null;
      })
      .filter(Boolean);

    const topRecommendations = recommendations.filter(
      (rec) => rec.similarity === 100
    );

    const additionalRecommendations = recommendations
      .filter((rec) => rec.similarity < 100)
      .sort((a, b) => b.similarity - a.similarity)
      .slice(0, 5 - topRecommendations.length);

    return [...topRecommendations, ...additionalRecommendations].slice(0, 5);
  }

  getWeightsByTab(tab: string) {
    const tabWeights = {
      시간보내기: {
        affinity: 0.3,
        sociability: 0.2,
        age: 0.2,
        bmi: 0.2,
        activity: 0.1,
      },
      건강케어: {
        internal: 0.3,
        surgical: 0.3,
        bmi: 0.2,
        age: 0.2,
      },
      우리집케어: {
        sociability: 0.3,
        affinity: 0.3,
        aggressive: 0.2,
        age: 0.2,
      },
      야외활동: {
        activity: 0.5,
        sociability: 0.2,
        affinity: 0.2,
        aggressive: 0.1,
      },
      산책하기: {
        activity: 0.3,
        affinity: 0.3,
        sociability: 0.2,
        aggressive: 0.2,
      },
      체중관리: {
        bmi: 0.4,
        age: 0.3,
        internal: 0.2,
        activity: 0.1,
      },
    };
    return tabWeights[tab] || tabWeights["시간보내기"];
  }

  jaccardSimilarity(userInfo, sitterInfo) {
    const userSet = new Set(
      [
        userInfo.size,
        userInfo.age,
        userInfo.bmi,
        userInfo.surgical,
        userInfo.internal,
        userInfo.activity,
        userInfo.sociability,
        userInfo.affinity,
        userInfo.aggressive,
      ].filter(Boolean)
    );
    const sitterSet = new Set(
      [
        sitterInfo.size_exp,
        sitterInfo.age_exp,
        sitterInfo.bmi_exp,
        sitterInfo.surgical_exp,
        sitterInfo.internal_exp,
        sitterInfo.activity_exp,
        sitterInfo.sociability_exp,
        sitterInfo.affinity_exp,
        sitterInfo.aggressive_exp,
      ].filter(Boolean)
    );

    const intersection = new Set([...userSet].filter((x) => sitterSet.has(x)));
    const union = new Set([...userSet, ...sitterSet]);

    return intersection.size / union.size;
  }

  calculateSimilarity(userInfo, sitterInfo, weights) {
    if ((userInfo.size || 0) !== (sitterInfo.size_exp || 0)) {
      return 0; // 크기가 일치하지 않으면 유사도 0
    }

    const ageScore =
      (weights.age || 0) *
      ((5 - Math.abs((userInfo.age || 0) - (sitterInfo.age_exp || 0))) / 5);
    const bmiScore =
      (weights.bmi || 0) *
      ((5 - Math.abs((userInfo.bmi || 0) - (sitterInfo.bmi_exp || 0))) / 5);
    const surgicalScore =
      (weights.surgical || 0) *
      ((5 -
        Math.abs((userInfo.surgical || 0) - (sitterInfo.surgical_exp || 0))) /
        5);
    const internalScore =
      (weights.internal || 0) *
      ((5 -
        Math.abs((userInfo.internal || 0) - (sitterInfo.internal_exp || 0))) /
        5);
    const activityScore =
      (weights.activity || 0) *
      ((5 -
        Math.abs((userInfo.activity || 0) - (sitterInfo.activity_exp || 0))) /
        5);
    const sociabilityScore =
      (weights.sociability || 0) *
      ((5 -
        Math.abs(
          (userInfo.sociability || 0) - (sitterInfo.sociability_exp || 0)
        )) /
        5);
    const affinityScore =
      (weights.affinity || 0) *
      ((5 -
        Math.abs((userInfo.affinity || 0) - (sitterInfo.affinity_exp || 0))) /
        5);
    const aggressiveScore =
      (weights.aggressive || 0) *
      ((5 -
        Math.abs(
          (userInfo.aggressive || 0) - (sitterInfo.aggressive_exp || 0)
        )) /
        5);

    // 각 속성의 최대값이 1로 조정된 상태로 총합을 100%로 반환
    const totalScore =
      ageScore +
      bmiScore +
      surgicalScore +
      internalScore +
      activityScore +
      sociabilityScore +
      affinityScore +
      aggressiveScore;

    return totalScore * 100; // 백분율로 변환
  }
}

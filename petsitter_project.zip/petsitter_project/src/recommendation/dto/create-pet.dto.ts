// dto/create-pet.dto.ts
export class CreatePetDto {
  size: number;
  age: number;
  bmi: number;
  surgical: number;
  internal: number;
  activity: number;
  sociability: number;
  affinity: number;
  aggressive: number;
}

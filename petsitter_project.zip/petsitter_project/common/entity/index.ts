// common/entity/index.ts

export * from "./user.entity";

//// common/entity/user.entity.ts

import { $Enums, User } from "@prisma/client";

export class UserEntity implements User {
  address: string;
  detailedAddress: string;
  email: string;
  id: string;
  name: string;
  nickname: string;
  password: string;
  phone: string;
  role: string = "CUSTOMER";
  gender: $Enums.Gender;
  birthdate: string;
  profileImageUrl: string | null;
  bio: string | null;
}

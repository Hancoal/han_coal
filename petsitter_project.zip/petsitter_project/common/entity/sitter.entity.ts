// common/entity/sitter.entity.ts

import { Sitter } from "@prisma/client";

export class SitterEntity implements Sitter {
  sitterNum: number;
  certification: string | null;
  experience: number | null;
  bio: string | null;
  userId: string;

  size_exp: number; // 1~3 사이의 값, 크기 전문성
  age_exp: number; // 1~5 사이의 값, 나이 전문성
  bmi_exp: number; // 1~5 사이의 값, 비만도 전문성
  surgical_exp: number; // 1~5 사이의 값, 외과적 질환 전문성
  internal_exp: number; // 1~5 사이의 값, 내과적 질환 전문성
  activity_exp: number; // 1~5 사이의 값, 활동성 전문성
  sociability_exp: number; // 1~5 사이의 값, 사교성 전문성
  affinity_exp: number; // 1~5 사이의 값, 친화력 전문성
  aggressive_exp: number; // 1~5 사이의 값, 공격성 전문성
}

// common/entity/pet.entity.ts

import { Pet } from "@prisma/client";

export class PetEntity implements Pet {
  id: number;
  name: string;
  userId: string;
  breed: string;

  size: number; // 1~3 사이의 값, 크기
  age: number; // 1~5 사이의 값, 나이
  bmi: number; // 1~5 사이의 값, 비만도
  surgical: number; // 1~5 사이의 값, 외과적 질환 정도
  internal: number; // 1~5 사이의 값, 내과적 질환 정도
  activity: number; // 1~5 사이의 값, 활동성
  sociability: number; // 1~5 사이의 값, 사교성
  affinity: number; // 1~5 사이의 값, 친화력
  aggressive: number; // 1~5 사이의 값, 공격성
  petImageUrl: string | null;
}

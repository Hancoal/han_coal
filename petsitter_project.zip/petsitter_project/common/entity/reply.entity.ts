// common/entity/reply.entity.ts

import { Reply } from "@prisma/client";

export class ReplyEntity implements Reply {
  id: number;
  content: string;
  date: Date;
  userId: string;
  boardId: number;
}

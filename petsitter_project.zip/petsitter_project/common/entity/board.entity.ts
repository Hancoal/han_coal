// common/entity/board.entity.ts

import { Board, $Enums } from "@prisma/client";

export class BoardEntity implements Board {
  id: number;
  title: string;
  content: string;
  date: Date;
  like: number;
  tag: $Enums.Tag;
  userId: string;
}

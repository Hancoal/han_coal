// common/entity/customer.entity.ts

import { Customer } from "@prisma/client";

export class CustomerEntity implements Customer {
  id: number;
  userId: string;
}

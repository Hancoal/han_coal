// common/guard/jwt-auth.guard.ts

import {
  Injectable,
  ExecutionContext,
  UnauthorizedException,
} from "@nestjs/common";
import { AuthGuard } from "@nestjs/passport";

@Injectable()
export class JwtAuthGuard extends AuthGuard("jwt") {
  canActivate(context: ExecutionContext) {
    return super.canActivate(context);
  }

  handleRequest(err: any, user: any, info: { message: any }) {
    if (err || !user) {
      console.error("Authentication Error:", info.message || info);
      throw new UnauthorizedException({
        message: info?.message || "인증되지 않은 사용자입니다.",
      });
    }
    return user;
  }
}
